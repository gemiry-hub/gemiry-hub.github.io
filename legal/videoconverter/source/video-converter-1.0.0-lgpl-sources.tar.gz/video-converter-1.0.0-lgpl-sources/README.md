# Video Converter 1.0.0: LGPL source code

This archive is the source code, and the scripts used to build them for Video Converter, of the
libraries the app ships under the GNU Lesser General Public License:

- LAME MP3 encoder 3.100 (libmp3lame)
- FFmpeg 7.1 (libavformat, libavcodec, libavutil, libswscale)

| Part | Where | What |
|---|---|---|
| FFmpeg | `ffmpeg/` | FFmpeg commit `b08d7969c550a804a59511c7b83f2dd8cc0499b8` (tag `n7.1`), complete, every file byte-for-byte as stored in git; licence `ffmpeg/COPYING.LGPLv2.1` |
| LAME | `lame-3.100/` | LAME 3.100, unmodified; upstream tarball SHA-256 `ddfe36cab873794038ae2c1210557ad34857a4b6bdc515785d1da9e175b1da1e`; licence `lame-3.100/COPYING` |
| Build scripts | `build/native/ffmpeg/` | `build-ffmpeg.sh` (the exact `./configure` line), `PINNED_COMMIT`, `README.md` |
| CMake and bridges | `build/core/engine/src/main/cpp/` | `CMakeLists.txt`, the hand-written LAME `config.h`, and the JNI bridge sources `lame_jni.c`, `ffmux_jni.c`, `ffdec_jni.c` |
| `build/shipped.sha256` | | SHA-256 of the FFmpeg `.so` files that shipped, one line per file |
| `MANIFEST.sha256` | | SHA-256 of every file here except `README.md` (which names the version) and itself: run `sha256sum -c MANIFEST.sha256` inside `video-converter-1.0.0-lgpl-sources/` |

The app links these libraries dynamically (`libmp3lame.so`, `libavformat.so`, `libavcodec.so`, `libavutil.so`,
`libswscale.so`), so you can replace any of them with your own build of the same source.

## Rebuild

Toolchain used: Android NDK `30.0.15729638`, CMake `4.1.2`, Android API 26, ABIs `arm64-v8a`, `armeabi-v7a`,
`x86_64`. FFmpeg is built with MSYS2 (mingw64 gcc, `make`, `nasm`); `build-ffmpeg.sh` has the NDK path
at its top, so edit that line to where your NDK lives.

1. Lay the parts out as the scripts expect (paths relative to `build/`):
   - copy `ffmpeg/` to `build/native/ffmpeg/ffmpeg/`
   - copy `lame-3.100/` to `build/native/lame/`
2. FFmpeg, one ABI per call, never in parallel:
   `cd build/native/ffmpeg && bash build-ffmpeg.sh arm64-v8a --prebuilt` (then `armeabi-v7a`, `x86_64`).
   The shared libraries land in `build/native/ffmpeg/prebuilt/<abi>/`. Compare them with `build/shipped.sha256`:
   the same toolchain gives the same bytes; another toolchain gives a working but different library.
3. LAME and the bridges, once per ABI (`<ndk>` is your NDK 30.0.15729638 folder):
   `cmake -S build/core/engine/src/main/cpp -B out/<abi> -G Ninja -DCMAKE_TOOLCHAIN_FILE=<ndk>/build/cmake/android.toolchain.cmake -DANDROID_ABI=<abi> -DANDROID_PLATFORM=android-26 -DCMAKE_BUILD_TYPE=Release`
   then `cmake --build out/<abi>`. It compiles `libmp3lame.so` and `libgemiry_mp3.so` from
   `build/native/lame/libmp3lame/*.c` and links the FFmpeg libraries from step 2.
